def stateTime(dbEntry, stateList, timeToAdd):
	
	timeToAdd = float(timeToAdd)
	
	if dbEntry['blocked'] == 1:
		stateList['blocked'] = stateList['blocked'] + timeToAdd/60.0
	elif dbEntry['starved'] == 1:
		stateList['starved'] = stateList['starved'] + timeToAdd/60.0
	elif dbEntry['faulted'] == 1:
		stateList['faulted'] = stateList['faulted'] + timeToAdd/60.0
	elif dbEntry['jogging'] == 1:
		stateList['jogging'] = stateList['jogging'] + timeToAdd/60.0
	elif dbEntry['running'] == 1:
		stateList['running'] = stateList['running'] + timeToAdd/60.0
	else:
		stateList['ready'] = stateList['ready'] + timeToAdd/60.0
	
	return stateList	