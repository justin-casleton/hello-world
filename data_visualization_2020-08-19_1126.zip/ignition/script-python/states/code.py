def setStateString(active_states):

	
	overrides = {
		  "BLOCKED": ["PAUSED", "FAULTED", "STARVED", "JOGGING"],
		  "STARVED": ["PAUSED", "FAULTED"],
		  "JOGGING": ["RUNNING"],
		  "RUNNING": ["READY"],
		  "PAUSED": ["READY"]
		}
		
	state_string = "UNKNOWN"
	
	for state in active_states:
		overridden = False
		override_exists = True
		
		try:
			overrides[state].index(state_string)
			overridden = True
		except ValueError: # Implies overrides[state] doesn't contain state_string
			pass
		except KeyError: # Implies overrides[state] doesn't exist.
			override_exists = False
		
		if state_string == "UNKNOWN" or (overridden and override_exists):
			state_string = state
	
	return state_string